//
//  showDrawVC.swift
//  DrawGif
//
//  Created by Ra mzy on 2/11/19.
//  Copyright © 2019 Ra mzy. All rights reserved.
//

import UIKit
import ImageIO
import MobileCoreServices
import Photos


class showDrawVC: UIViewController {

    var showDrawLines =  [Line]()
    var arr: [UIImage] = []

    
    @IBOutlet weak var showDrawView: DrawView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    @IBAction func PlayAction(_ sender: UIButton) {
        
//       var theDrawView = showDrawView as! DrawView
//           theDrawView.lines = showDrawLines


         let graphPath = UIBezierPath()
         let lineLayer = CAShapeLayer()

        for line in showDrawLines {

//            for item in  0...showDrawLines.count {
//
//                if item % 10 == 0 {
//                    print("\n ==> \(item)")
//                    print("\n Count: \(showDrawLines.count)")
//                    //takeImageShot()
//                }
//            }
            
//            let graphPath = UIBezierPath()
//            let lineLayer = CAShapeLayer()
            
            graphPath.move(to:  line.Start)
            graphPath.addLine(to: line.End)

            lineLayer.lineWidth         = 5.0
            lineLayer.path              = graphPath.cgPath
            lineLayer.strokeColor       = line.Color
            lineLayer.fillColor         = UIColor.clear.cgColor
            lineLayer.lineCap           = kCALineCapRound
            lineLayer.strokeEnd         = 0


            let basicAnimation          = CABasicAnimation(keyPath: "strokeEnd")
                basicAnimation.toValue  = 1
                basicAnimation.duration = 4
                basicAnimation.fillMode = kCAFillModeForwards
                basicAnimation.isRemovedOnCompletion = false

            lineLayer.add( basicAnimation,   forKey: "strokeEnd" )

            showDrawView.layer.addSublayer(lineLayer)
            showDrawView.layer.setNeedsDisplay()

        }
        

       // showDrawView.layer.addSublayer(lineLayer)
       // showDrawView.layer.setNeedsDisplay()

        
        // Do any additional setup after loading the view, typically from a nib.
        Timer.scheduledTimer(withTimeInterval: 0.1, repeats: true) { (timer) in
//            self.colorView.backgroundColor = UIColor.random()
            self.arr.append( self.showDrawView.takeScreenshot() )
        }
        
        
//        let renderer2 = UIGraphicsImageRenderer(size: CGSize(width: 375, height: 311))
//        let img2 = renderer2.image { ctx in
//
//            for line in showDrawLines {
//
//            ctx.cgContext.move(to: line.Start)
//            ctx.cgContext.addLine(to: line.End)
//            ctx.cgContext.setStrokeColor(line.Color)
//            ctx.cgContext.strokePath()
//
//            }
//        }
//
//        imageView.image = img2
        
    }
    
    
    @IBAction func showGif(_ sender: UIButton) {
        
        animatedGif(from: arr)
    }
    
    
    func animatedGif(from images: [UIImage]) {
        
        
        let fileProperties: CFDictionary = [kCGImagePropertyGIFDictionary as String: [kCGImagePropertyGIFLoopCount as String: 0]]  as CFDictionary
        let frameProperties: CFDictionary = [kCGImagePropertyGIFDictionary as String: [(kCGImagePropertyGIFDelayTime as String): 1.0]] as CFDictionary
        
        let documentsDirectoryURL: URL? = try? FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
        let fileURL: URL? = documentsDirectoryURL?.appendingPathComponent("animated.gif")
        
        if let url = fileURL as CFURL? {
            
            if let destination = CGImageDestinationCreateWithURL(url, kUTTypeGIF, images.count, nil) {
                CGImageDestinationSetProperties(destination, fileProperties)
                for image in images {
                    if let cgImage = image.cgImage {
                        CGImageDestinationAddImage(destination, cgImage, frameProperties)
                    }
                }
                
                if CGImageDestinationFinalize(destination) {
                    
                    let data = try? Data(contentsOf: fileURL!)
                    guard let mData = data else { return }
                    PHPhotoLibrary.shared().performChanges({
                        PHAssetCreationRequest.forAsset().addResource(with: .photo, data: mData, options: nil)
                    }) { success, error in
                        guard success else {
                            print("failed to save gif \(error)")
                            return
                        }
                        print("successfully saved gif")
                    }
                    
                }
                
                
            } else { print("failed") }
            
            //                if !CGImageDestinationFinalize(destination) {
            //                    print("Failed to finalize the image destination")
            //                }
            print("Url = \(fileURL)")
            
        }
    }
}





extension UIView {
    
    func takeScreenshot() -> UIImage {
        
        // Begin context
        UIGraphicsBeginImageContextWithOptions(self.bounds.size, false, UIScreen.main.scale)
        
        // Draw view in that context
        drawHierarchy(in: self.bounds, afterScreenUpdates: true)
        
        // And finally, get image
        let image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        
        if (image != nil)
        {
            return image!
        }
        return UIImage()
    }
}


//------------ Save View as Image ---
//view.drawHierarchy(in: view.bounds, afterScreenUpdates: true)
//let image = UIGraphicsGetImageFromCurrentImageContext()
//UIGraphicsEndImageContext()
//
//let data = UIImagePNGRepresentation(image!)
//
//let userDefaults = UserDefaults.standard
//userDefaults.set(data, forKey: "snapshot")
//userDefaults.synchronize()
//
//imagesArr.append(image!)
